# unused instructions

## Tile map functions

Tile map functions are available via the global tilemap object.  Each tile has a tile ID which indicates what tile to show, and a tile mask which can be used to indicate tile type for collisions. 

tilemap.getTilePos(tilex,tiley) - get tile at position tilex,tiley

tilemap.setTile(tileid, tilemask, tilex, tiley) - set tile at position tilex,tiley to given tileid and tilemask

tilemap.fill(tileidx,tilemask,x1,y1,x2,y2) - fill area at positions x1,y1,x2,y2 (x2,y2 exclusive) with given tileid and tilemask
