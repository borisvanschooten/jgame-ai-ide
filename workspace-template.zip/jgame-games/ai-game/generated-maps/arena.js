/*@webcogs_build 0.6.0 openai-gpt-5.4 2026-05-19T18:23:45.224Z
@webcogs_system_prompt
# General instructions

You are writing Javascript functions and classes.

Use 4 spaces for indenting.  Functions are always export functions. 

## Random functions

Always use the following random functions:

random2(min, max) - generate a random float between min (inclusive) and max (exclusive)

randomstep2(min, max, interval) - generate a random number between min (inclusive) and max (inclusive) with interval steps.  For any interval=n, it creates a number which is always increments of n from min. For example, if interval=1, it creates an integer between min and max. 

srand2(seed) - seeds the random function

# Defining game maps

A map is is defined as an array of equal length strings.  Each string indicates a horizontal row of the map.  Each character in the string is translated to either a tile or a game entity. A map can be defined by a map generator function, which has the following signature:

myMapGeneratorFunction(xsize,ysize, seed, {extraParameters}) - returns an array of strings of at most the given size. xsize is the size of each string, ysize is the size of the array; seed is the random seed. Extra parameters can be added to configure the map generation, via a named parameter object, with default values for each, specified using parameter destructuring, e.g. {parameter1,parameter2,...}={}.  Add configuration parameters for anything that is meaningful to configure.  Also add configuration parameters for the map characters/tiles. For these, use the following naming pattern: [tile name]Char.

The minimum size that should be supported is 32x18. Make the generator function configurable.


@webcogs_user_prompt
Create a function that generates a level map for a game. Each tile on the map is either: wall (#), empty (.), player (P), enemy (e). The description follows. 
A level with empty tiles, with some horizontal and vertical walls of wall tiles. The walls should be at least 2 tiles away from each other and from the edge of the screen. Place the player in the middle, and some enemies in empty spaces, at least 6 tiles away from the player.
@webcogs_end_prompt_section*/
export function generateLevelMap(xsize, ysize, seed, {
    wallChar = '#',
    emptyChar = '.',
    playerChar = 'P',
    enemyChar = 'e',
    minWallLength = 3,
    maxWallLength = 8,
    wallAttempts = 18,
    enemyCount = 6,
    minEnemyDistanceFromPlayer = 6,
    wallPadding = 2
} = {}) {
    const width = Math.max(32, xsize);
    const height = Math.max(18, ysize);

    srand2(seed);

    const map = Array.from({ length: height }, () => Array(width).fill(emptyChar));

    const playerX = Math.floor(width / 2);
    const playerY = Math.floor(height / 2);

    function inBounds(x, y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }

    function isWall(x, y) {
        return inBounds(x, y) && map[y][x] === wallChar;
    }

    function canPlaceWallSegment(x, y) {
        if (!inBounds(x, y)) {
            return false;
        }
        if (x < wallPadding || x >= width - wallPadding || y < wallPadding || y >= height - wallPadding) {
            return false;
        }
        if (map[y][x] !== emptyChar) {
            return false;
        }

        for (let yy = y - wallPadding; yy <= y + wallPadding; yy++) {
            for (let xx = x - wallPadding; xx <= x + wallPadding; xx++) {
                if (!inBounds(xx, yy)) {
                    continue;
                }
                if (isWall(xx, yy)) {
                    return false;
                }
            }
        }

        if (Math.abs(x - playerX) <= 1 && Math.abs(y - playerY) <= 1) {
            return false;
        }

        return true;
    }

    for (let i = 0; i < wallAttempts; i++) {
        const horizontal = randomstep2(0, 1, 1) === 0;
        const length = randomstep2(minWallLength, maxWallLength, 1);
        const startX = randomstep2(wallPadding, width - wallPadding - 1, 1);
        const startY = randomstep2(wallPadding, height - wallPadding - 1, 1);

        const cells = [];
        let valid = true;

        for (let j = 0; j < length; j++) {
            const x = startX + (horizontal ? j : 0);
            const y = startY + (horizontal ? 0 : j);

            if (!canPlaceWallSegment(x, y)) {
                valid = false;
                break;
            }

            cells.push([x, y]);
        }

        if (!valid) {
            continue;
        }

        for (const [x, y] of cells) {
            map[y][x] = wallChar;
        }
    }

    map[playerY][playerX] = playerChar;

    let placedEnemies = 0;
    let enemyAttempts = 0;
    const maxEnemyAttempts = width * height * 4;

    while (placedEnemies < enemyCount && enemyAttempts < maxEnemyAttempts) {
        enemyAttempts++;
        const x = randomstep2(0, width - 1, 1);
        const y = randomstep2(0, height - 1, 1);

        if (map[y][x] !== emptyChar) {
            continue;
        }

        const distance = Math.abs(x - playerX) + Math.abs(y - playerY);
        if (distance < minEnemyDistanceFromPlayer) {
            continue;
        }

        map[y][x] = enemyChar;
        placedEnemies++;
    }

    return map.map((row) => row.join(''));
}