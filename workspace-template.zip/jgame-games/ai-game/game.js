// Game init script
// title and description are set by UI, the rest is untouched

GameConfig.title = 'My Game'
GameConfig.description = 'Controls:\nW,S,A,D=move  cursors=shoot.\nGame controller: left stick=move, right stick=shoot'

GameConfig.loadGame = async function() {
	GameConfig.levels = await loadJSON("levels.json")
	tilemapping = await loadJSON("tilemapping.json")
	spritedefs = await loadJSON("sprites.json")
	gameglobals = await loadJSON("globals.json")
}
